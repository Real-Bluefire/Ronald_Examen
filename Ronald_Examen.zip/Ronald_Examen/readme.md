# ESTUDIANTE: RONALD SAID HERNANDEZ MONTOYA
# CUENTA: 202110060501

## Monitor del Sistema con Django y Psutil

Este proyecto es una aplicación web creada con Django que permite visualizar en tiempo real el estado del sistema. Muestra el uso del CPU, memoria RAM, almacenamiento en disco y otros datos del sistema operativo usando la librería psutil.




## Instrucciones para ejecutar el proyecto localmente:

1. Abre la terminal y entra a la carpeta del proyecto:
cd .\Ronald_Examen

2. Crear entorno virtual:
python -m venv venv

3. Activar entorno virtual: 
.\venv\Scripts\Activate.ps1

4. Instala las dependencias necesarias:
pip install -r requirements.txt

5. Aplica las migraciones:
python manage.py migrate

6. Inicia el servidor de desarrollo:
python manage.py runserver

7. Abre el navegador y entra a:
http://127.0.0.1:8000/




## Instalación de dependencias:

# Django: framework para construir la aplicación web. Instálalo con:

pip install django

# Psutil: librería para obtener información del sistema. Instálala con:

pip install psutil




## Explicación de componentes:

# collectors.py: 
obtiene los datos del CPU, memoria, disco y sistema operativo.

# views.py: 
conecta los datos con las plantillas.

# urls.py: 
define las rutas de acceso.

# templates/sistema/index.html: 
muestra los datos en la página.

# static/sistema/monitor.js: 
permite actualizar la información manual o automáticamente.