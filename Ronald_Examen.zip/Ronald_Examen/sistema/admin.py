# ESTUDIANTE: RONALD SAID HERNANDEZ MONTOYA
# CUENTA: 202110060501

from django.contrib import admin

# Register your models here.
