# ESTUDIANTE: RONALD SAID HERNANDEZ MONTOYA
# CUENTA: 202110060501

import psutil
import platform

def get_cpu_usage():
    try:
        return psutil.cpu_percent(interval=0.5)
    except Exception:
        return -1

def get_memory_info():
    try:
        mem = psutil.virtual_memory()
        return {
            'used_gb': round((mem.total - mem.available) / (1024 ** 3), 2),
            'total_gb': round(mem.total / (1024 ** 3), 2),
            'percent': mem.percent,
        }
    except Exception:
        return {'used_gb': -1, 'total_gb': -1, 'percent': -1}

def get_disk_info():
    try:
        disk = psutil.disk_usage('/')
        return {
            'used_gb': round(disk.used / (1024 ** 3), 2),
            'total_gb': round(disk.total / (1024 ** 3), 2),
            'percent': disk.percent,
        }
    except Exception:
        return {'used_gb': -1, 'total_gb': -1, 'percent': -1}

def get_system_info():
    try:
        return {
            'system': platform.system(),
            'release': platform.release(),
            'version': platform.version(),
            'cores_logical': psutil.cpu_count(logical=True),
            'cores_physical': psutil.cpu_count(logical=False),
        }
    except Exception:
        return {'system': 'unknown'}
