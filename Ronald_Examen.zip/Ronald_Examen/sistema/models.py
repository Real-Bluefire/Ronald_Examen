# ESTUDIANTE: RONALD SAID HERNANDEZ MONTOYA
# CUENTA: 202110060501

from django.db import models

# Create your models here.
