# ESTUDIANTE: RONALD SAID HERNANDEZ MONTOYA
# CUENTA: 202110060501

from django.shortcuts import render
from django.http import JsonResponse
from . import collectors

def index(request):
    data = {
        'cpu': collectors.get_cpu_usage(),
        'memory': collectors.get_memory_info(),
        'disk': collectors.get_disk_info(),
        'system': collectors.get_system_info(),
    }
    return render(request, 'sistema/index.html', data)

def api_metrics(request):
    data = {
        'cpu': collectors.get_cpu_usage(),
        'memory': collectors.get_memory_info(),
        'disk': collectors.get_disk_info(),
        'system': collectors.get_system_info(),
    }
    return JsonResponse(data)
