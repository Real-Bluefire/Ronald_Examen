// ESTUDIANTE: RONALD SAID HERNANDEZ MONTOYA
// CUENTA: 202110060501

async function fetchMetrics(){
  try{
    const res = await fetch('/api/metrics/');
    const data = await res.json();
    document.getElementById('cpu').innerText = data.cpu + ' %';
    document.getElementById('memory').innerText = `${data.memory.used_gb}/${data.memory.total_gb} GB (${data.memory.percent}%)`;
    document.getElementById('disk').innerText = `${data.disk.used_gb}/${data.disk.total_gb} GB (${data.disk.percent}%)`;
    document.getElementById('system').innerText = `${data.system.system} ${data.system.release} - Núcleos: ${data.system.cores_physical} físicos / ${data.system.cores_logical} lógicos`;
  }catch{
    document.getElementById('cpu').innerText = 'Error';
    document.getElementById('memory').innerText = 'Error';
    document.getElementById('disk').innerText = 'Error';
    document.getElementById('system').innerText = 'Error';
  }
}

document.getElementById('refreshBtn').addEventListener('click', fetchMetrics);

let timer;
document.getElementById('startAuto').addEventListener('click', ()=>{
  const s = parseInt(document.getElementById('intervalInput').value) || 5;
  if(timer) clearInterval(timer);
  timer = setInterval(fetchMetrics, s*1000);
});

document.getElementById('stopAuto').addEventListener('click', ()=>{
  if(timer) clearInterval(timer);
  timer = null;
});

fetchMetrics();
