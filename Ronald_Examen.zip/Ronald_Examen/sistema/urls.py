# ESTUDIANTE: RONALD SAID HERNANDEZ MONTOYA
# CUENTA: 202110060501

from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('api/metrics/', views.api_metrics, name='api_metrics'),
]
